import java.util.Scanner;

public class C4E3EstimateAreas
{
	public static void main(String[] args)
	{
		
		final double radius = 6371.01;
		double AtlantaLongitude  = -84.3879824 , AtlantaLatitude = 33.7489954;
		double OrlandoLongitude = -81.37923649999999 , OrlandoLatitude = 28.5383355;
		double SavannahLongitude = -81.09983419999998 , SavannahLatitude = 32.0835407;
		double CharlotteLongitude = -80.84312669999997 , CharlotteLatitude = 35.2270869;
		// toRadians
		double AtlantaLo = Math.toRadians(AtlantaLongitude); double AtlantaLa = Math.toRadians(AtlantaLatitude);
		double OrlandoLo = Math.toRadians(OrlandoLongitude); double OrlandoLa = Math.toRadians(OrlandoLatitude);
		double SavannahLo = Math.toRadians(SavannahLongitude); double SavannahLa = Math.toRadians(SavannahLatitude);
		double CharlotteLo = Math.toRadians(CharlotteLongitude); double CharlotteLa = Math.toRadians(CharlotteLatitude);	
	
		System.out.println(" This program is uesd to compute the estimated area enclosed by these four cities : Atlanta, Georgia; Orlando, Florida; Savannah, Georgia; and Charlotte, North Carolina. \n"); 
		System.out.print("The GPS locations (longitude, latitude) for \n" + " Atlanta, Georgia : -84.3879824 , 33.7489954 \n" + " Orlando, Florida : -81.37923649999999 , 28.5383355 \n" + " Savannah, Georgia : -81.09983419999998 , 32.0835407 \n" + " Charlotte, North Carolina : -80.84312669999997 , 35.2270869 \n" + '\n');

		double dAO = radius * Math.acos( Math.sin(AtlantaLa) * Math.sin(OrlandoLa) + Math.cos(AtlantaLa) * Math.cos(OrlandoLa) * Math.cos(AtlantaLo - OrlandoLo) );
		double dSO = radius * Math.acos( Math.sin(SavannahLa) * Math.sin(OrlandoLa) + Math.cos(SavannahLa) * Math.cos(OrlandoLa) * Math.cos(SavannahLo - OrlandoLo) );
		double dAS = radius * Math.acos( Math.sin(AtlantaLa) * Math.sin(SavannahLa) + Math.cos(AtlantaLa) * Math.cos(SavannahLa) * Math.cos(AtlantaLo - SavannahLo) );
		
		double sAOS = (dAO + dSO + dAS) / 2;
		double areaTriangleAOS = Math.pow( ( sAOS * (sAOS - dAO) * (sAOS - dSO) * (sAOS - dAS) ) , 0.5 );
		System.out.print(" The distance between Atlanta and Orlando : " + dAO + " km \n " + "The distance between Savannah and Orlando : " + dSO + " km \n " + "The distance between Atlanta and Savannah : " + dAS + " km \n ");

		double dCO = radius * Math.acos( Math.sin(CharlotteLa) * Math.sin(OrlandoLa) + Math.cos(CharlotteLa) * Math.cos(OrlandoLa) * Math.cos(CharlotteLo - OrlandoLo) );
		double dCS = radius * Math.acos( Math.sin(CharlotteLa) * Math.sin(SavannahLa) + Math.cos(CharlotteLa) * Math.cos(SavannahLa) * Math.cos(CharlotteLo - SavannahLo) );
		double dAC = radius * Math.acos( Math.sin(AtlantaLa) * Math.sin(CharlotteLa) + Math.cos(AtlantaLa) * Math.cos(CharlotteLa) * Math.cos(AtlantaLo - CharlotteLo) );
		double sACS = (dAC + dAS + dCS) / 2;
		double areaTriangleACS = Math.pow( ( sACS * (sACS - dAC) * (sACS - dAS) * (sACS - dCS) ) , 0.5 );
		System.out.print("The distance between Charlotte and Orlando : " + dCO + " km (this distance is not used to calculate the area)\n " + "The distance between Charlotte and Savannah : " + dCS + " km \n " + "The distance between Atlanta and Charlotte : " + dAC + " km \n ");	
		
		System.out.print(" I use triangle AOS and triangle ACS to calculate the whole area. And the area of AOS is " + areaTriangleAOS + " Square kilometer . The area of COS is " + areaTriangleACS + " Square kilometer . \n");
		double areaTotal = areaTriangleAOS + areaTriangleACS;
		System.out.print("The estimated area enclosed by these four cities (Atlanta, Georgia; Orlando, Florida; Savannah, Georgia; and Charlotte, North Carolina) is " + areaTotal + " Square kilometer");
	} 
}