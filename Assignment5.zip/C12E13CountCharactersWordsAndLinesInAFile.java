
import java.io.FileNotFoundException;
import java.util.*;

public class C12E13CountCharactersWordsAndLinesInAFile {
	
//	java.io.File f = new java.io.File(this.getClass().getResource("").getPath()); 
//	String route = f.getAbsolutePath();
	public static void main(String args[])
	{
		Scanner input = new Scanner(System.in);
		String intro = 
	    		"This program is a method that count characters, words, and lines in a file.\n" + 
	    		" The users can enter the name of the txt.(the txt. must in the current project path directory). If the txt. is not existed, program will throw an exception. "
	    		+ "Or users will get the information of characters, words, and lines of the txt. ";    
	    System.out.println(intro); 
	    int repeatInt = 1;//0 to quit
	    int choose_input = -1;
	    while (repeatInt != 0)
	    {
	    	System.out.print("Please choose which founction you want to use:\n" + "1:count characters, words, and lines in your txt. ��  \n" + "0:choose this to quit\n");
	    	choose_input = input.nextInt();
	    	if (choose_input == 0)
	    	{
	    		repeatInt = 0;
	    	}
	    	else if (choose_input == 1)//
	    	{
	    		System.out.print("Please enter the name of file:(like: XXX.txt)");
	    		String fileName = input.next();
	    		
	    		try {	    			
	    			boolean existF = isExist(fileName);
	    			//System.out.println(validS);
	    			if(existF)
	    			{
	    				java.io.File file = new java.io.File(fileName);
	    				String fileNameGet = file.getName();
	    				Scanner inputFile = new Scanner(file);
	    				int countChar = 0, countWord = 0, countLine = 0;
	    				while (inputFile.hasNextLine()) {
	    					String thisLine = inputFile.nextLine();
	    					countLine++;
	    					String temp[] = thisLine.split(" ");
	    					countWord += temp.length;
	    					for ( int i = 0 ; i < temp.length ; i++)
	    					{
	    						countChar += temp[i].length();
	    					}
	    				}
	    				System.out.println(fileNameGet + " has \n" + countChar + " characters \n" + countWord + " words \n" + countLine + " lines \n");
//	    				int countChar = countFileChar(fileName);
//	    				int countWord = countFileWord(fileName);
//	    				int countLine = countFileLine(fileName);
	    			}
	    		}
	    		catch (Exception ex)
	    		{
	    			System.out.println(ex);
	    		}
	    	}
	    	else {
	    		System.out.println("Invalid input! \n");
	    	}
	    }
	}
	
	public static boolean isExist(String fileName) throws Exception
	{
		boolean validSymbol = true;
//		String fileAdd = new java.io.File("").getAbsolutePath();
//		System.out.println(fileAdd);
//		//String fileAdd = new java.io.File("").getAbsolutePath();
//		
//		String temp = fileAdd + fileName;
		java.io.File file = new java.io.File(fileName);
		validSymbol = file.exists();
		//System.out.println(validSymbol);
		if(validSymbol)
		{
			
		}
		else {
			throw new Exception("The file is not existed!");
		}
		return validSymbol;
	}

}
