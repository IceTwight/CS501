
import java.util.*;

public class C9E1Rectangle {
	private double width;
	private double height;
	
	public C9E1Rectangle()
	{
		
	}
	
	public C9E1Rectangle(double wid, double hei)
	{
		setWidth(wid);
		setHeight(hei);
	}
	
	public void setWidth (double setW) throws IllegalArgumentException
	{
		if(setW > 0)
		 width = setW;
		else
			throw new IllegalArgumentException("width cannot be negative");
	}
	
	public void setHeight(double setH) throws IllegalArgumentException
	{
		if(setH > 0)
			 height = setH;
			else
				throw new IllegalArgumentException("height cannot be negative");
	}
	
	public double getWidth()
	{
		return width;
	}
	
	public double getHeight()
	{
		return height;
	}
	
	public double getArea()
	{
		return width * height;
	}
	
	public double getPerimeter()
	{
		return 2 * (width + height);
	}
	
	public void printRectangle()
	{
		System.out.println("The rectangle's information is as follows:");
	    System.out.println("width: " + this.getWidth() + " height: " + this.getHeight() + " area: " + this.getArea() +" perimeter: " + this.getPerimeter() );
	}
}
