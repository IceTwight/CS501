
public class Triangle extends GeometricObject{
	
	private String color = "";
	private boolean filled; 
	public Triangle()
	{
		setSide1(1);
		setSide2(1);
		setSide3(1);
	}
	public Triangle(double S1 , double S2 , double S3) throws IllegalTriangleException{
		
		if((S1+S2 > S3+0.000001)&&(S1+S3 > S2+0.000001)&&(S3+S2 > S1+0.000001))
		{		
			setSide1(S1);
			setSide2(S2);
			setSide3(S3);
		}
		else if ((S1+S2 <= S3+0.000001))
		{
//			System.out.println(S1+S2);
//			System.out.println(S3);
			throw new IllegalTriangleException(" The sum of Side1 and Side2 is equal or less than value of Side3! ");
		}
		else if ((S1+S3 <= S2+0.000001))
		{
			throw new IllegalTriangleException(" The sum of Side1 and Side3 is equal or less than value of Side2! ");
		}
		else if ((S3+S2 <= S1+0.000001))
		{
			throw new IllegalTriangleException(" The sum of Side3 and Side2 is equal or less than value of Side1! ");
		}
	}
	
//	public class IllegalTriangleException extends Exception {
//		 
//	}
//	
	public void setSide1(double newS1)
	{
		if(newS1 > 0)
			side1 = newS1;
			else
				throw new IllegalArgumentException("Side1 cannot be negative");
	}
	public void setSide2(double newS2)
	{
		if(newS2 > 0)
			side2 = newS2;
			else
				throw new IllegalArgumentException("Side2 cannot be negative");
	}
	public void setSide3(double newS3)
	{
		if(newS3 > 0)
			side3 = newS3;
			else
				throw new IllegalArgumentException("Side3 cannot be negative");
	}
	
	public double getSide1()
	{
		return side1;
	}
	public double getSide2()
	{
		return side2;
	}	
	public double getSide3()
	{
		return side3;
	}
	
	public double getArea()
	{
		double s1 = getSide1();
		double s2 = getSide2();
		double s3 = getSide3();
		//System.out.print(s1+ " "+ s2 + s3);
		double s = (s1 + s2 + s3)/2;
		//System.out.print(s+"{{{{{{{}}}}}S" + getSide1()+getSide2()+getSide3());
		double area = Math.pow( ( s * (s - s1) * (s - s2) * (s - s3) ) , 0.5 );
		return area;
	}
	
	public double getPerimeter()
	{
		double s1 = getSide1();
		double s2 = getSide2();
		double s3 = getSide3();
		return s1+s2+s3;
	}
	
	public String toString()
	{
		return "Triangle: side1 = " + getSide1() + " side2 = " + getSide2() + " side3 = " + getSide3();
	}
	
	public String getColor()
	{
		return color;
	}
	
	public void setColor(String color)
	{
		this.color = color;
	}
	
	public boolean isFilled()
	{
		return filled;
	}
	
	public void setFilled(boolean filled)
	{
		this.filled = filled;
	}
	
	public void display()
	{
		String sides = this.toString();
		String fill = "";
		boolean filledOrNot = this.isFilled();
		if(filledOrNot)
		{
			fill = "filled";
		}
		else
		{
			fill = "not filled";
		}
		System.out.println(sides + '\n' +"area = " +this.getArea()+'\n' + "perimeter = " + this.getPerimeter() +'\n' + "color = " + this.getColor() + 
				'\n' +"filled or not = " + fill );
	}
}
