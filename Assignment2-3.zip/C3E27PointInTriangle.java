import java.util.Scanner;

public class C3E27PointInTriangle
{
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		System.out.println(" There is a right triangle whose 3 points' coordinates are : (0, 0), (200, 0), and (0, 100). This program is used to prompts the user to enter a point with x- and y-coordinates and determines whether the point is inside the triangle.");
		System.out.println(" User needs to enter x- and y-coordinates separated by spaces.");
		System.out.print(" Enter a point's x- and y-coordinates: ");
		double x1 = input.nextDouble();
		double y1 = input.nextDouble();

		if ( x1 > 0 && y1 > 0 && ( 2.0 * y1 + x1 ) < 200 )
		{
			System.out.println(" The point is in the triangle ");
		}
		else
		{
			System.out.println(" The point is not in the triangle ");
		}
	}
}