public class C1E11Population
{
	public static void main(String[] args)
	{
		int time1 = 3600 * 24 * 365 ;
		int population0 = 312032486 ;
		double addi =  time1 / 7.0 + time1 / 45.0 - time1 / 13.0 ;
		
		System.out.println("The population now is : " + population0 );
		int population1 = population0 + (int)(addi * 1) ;
		int population2 = population0 + (int)(addi * 2) ;
		int population3 = population0 + (int)(addi * 3) ;	
		int population4 = population0 + (int)(addi * 4) ;
		int population5 = population0 + (int)(addi * 5) ;	
		System.out.println("The population after 1 year is : " + population1 );
		System.out.println("The population after 2 years is : " + population2 );
		System.out.println("The population after 3 years is : " + population3 );
		System.out.println("The population after 4 years is : " + population4 );
		System.out.println("The population after 5 years is : " + population5 );
	}
}