
import javafx.application.*;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.*;
import javafx.scene.text.Text;
import javafx.scene.shape.Rectangle;

public class Exercise14_12 extends Application{
	@Override // Override the start method in the Application class
	public void start(Stage primaryStage) 
	{
		Pane pane = new Pane();
		double widthRec = 90;
		
		Rectangle r1 = new Rectangle(10, 60, widthRec, 40);
		r1.setFill(Color.RED);
		pane.getChildren().add(new Text(10, 55, "Project -- 20%"));
		pane.getChildren().add(r1);
		
		Rectangle r2 = new Rectangle(10 + widthRec + 10, 80, widthRec, 20);
		r2.setFill(Color.BLUE);
		pane.getChildren().add(new Text(10 + widthRec + 10, 75, "Quiz -- 10%"));
		pane.getChildren().add(r2);
		
		Rectangle r3 = new Rectangle(10 + 2 * (widthRec + 10), 40, widthRec, 60);
		r3.setFill(Color.GREEN);
		pane.getChildren().add(new Text(10 + 2 * (widthRec + 10), 35, "Midterm -- 30%"));
		pane.getChildren().add(r3);
		
		Rectangle r4 = new Rectangle(10 + 3 * (widthRec + 10), 20, widthRec, 80);
		r4.setFill(Color.ORANGE);
		pane.getChildren().add(new Text(10 + 3 * (widthRec + 10), 15, "Final -- 40%"));
		pane.getChildren().add(r4);
		
		Scene scene = new Scene(pane, 410 , 110);
		primaryStage.setTitle("Exercise14_12");
		primaryStage.setScene(scene);
		primaryStage.show();
		
	}
	
	public static void main(String[] args) {
		Application.launch(args);
		}
}
