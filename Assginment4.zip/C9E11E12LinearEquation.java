

public class C9E11E12LinearEquation {
	private double a,b,c,d,e,f;
	
	public C9E11E12LinearEquation() {};
	
	public C9E11E12LinearEquation (double A, double B, double C, double D, double E, double F) 
	{
		a = A;
		b = B;
		c = C;
		d = D;
		e = E;
		f = F;			
	}
	
	public double getterA()
	{
		return a;
	}
	public double getterB()
	{
		return b;
	}
	public double getterC()
	{
		return c;
	}
	public double getterD()
	{
		return d;
	}
	public double getterE()
	{
		return e;
	}
	public double getterF()
	{
		return f;
	}
	
	public boolean isSolvable(){
		boolean isSolve = true;
		
		if(( a * d - b * c ) == 0)
		{
			isSolve = false;
			System.out.println("The equation has no solution."); 
		}
		return isSolve;
	}
	
	public double getX()
	{
		double x = ( e * d - b * f ) / ( a * d - b * c );
		return x;
	}
	public double getY()
	{
		double y = ( a * f - e * c ) / ( a * d - b * c );
		return y;
	}

}
