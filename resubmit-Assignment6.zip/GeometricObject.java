

public class GeometricObject {
	protected double x;
	protected double y; 
	protected double height;
	protected double width;
	protected double side1, side2, side3 ;
	
	public GeometricObject()
	{
		
	}
	
	public void setX(double newX)
	{
		x = newX;
	}
	public double getX()
	{
		return x;
	}
	
	public void setY(double newY)
	{
		y = newY;
	}
	public double getY()
	{
		return 1;
	}
	
	public void setHeight(double newH)
	{
		if(newH > 0)
			height = newH;
			else
				throw new IllegalArgumentException("height cannot be negative");
	}
	public double getHeight()
	{
		return height;
	}
	
	public void setWidth(double newW)
	{
		if(newW > 0)
			width = newW;	
			else
				throw new IllegalArgumentException("width cannot be negative");

	}
	public double getWidth()
	{
		return 0;
	}
	
	public double getArea()
	{
		return 0;
	}
	
	public double getPerimeter()
	{
		return 0;
	}
	
	public String toString()
	{
		return "";
	}
	
	public class IllegalTriangleException extends Exception{
		public IllegalTriangleException() {
	    }

	    public IllegalTriangleException(String message) {
	        super(message);
	    }
	}
	
}
