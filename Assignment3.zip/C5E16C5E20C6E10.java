
import java.util.Scanner;
import java.util.Arrays;

public class C5E16C5E20C6E10 {
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		//Find the factors of an integer
		int repeatInt = 1;
		int functionInt = 0;
	    String intro = 
	    		"The functions of this program are as follows:\n" + "1.Find the factors of an integer: Users can input 1 to use this function. Users can input an integer(like:120) and all its smallest factors in increasing order will be displayed. \n" 
	    				+ "2.Display prime numbers: Users can input 2 to use this function. The first 50 prime numbers will shown on the screen."
	    				+ "Then users can input 1 to show prime numbers between 2 and 1000 or users can input an integer(like:120) between 2 and 1000 to test if the number is prime \n"
	    				+ "3.Use the isPrime Method: Users can input 3 to use this function.Then the number of prime numbers less than 10000 will be displayed.";    
	    
		int result_2_1000[] = new int[1000];//2-1000 E2
		for(int i = 0 ; i < result_2_1000.length ; i++)
		{ 
			result_2_1000[i] = 0;
		}
	    
    	System.out.println(intro);
	    while(repeatInt != 0) {
	    // beginning of code lines responding to the exercise
	    	System.out.print("Choose a function: enter 1 for function1 and 2 for function 2 and 3 for function 3 :");
	    	functionInt = input.nextInt();
	    	switch (functionInt)
	    	{
	    		case 1:
	    			System.out.print("Please enter an interger(like:120) :");
	    			int number1 = input.nextInt();
	    			findTheFactorsOfAnInteger(number1);
	    			break;
	    		case 2:
	    			displayPrimeNumber();
	    			System.out.print("Please enter 1 to show prime numbers between 2 and 1000 or enter an integer between 2 and 1000(like:120) to test if the number is prime :");
	    			int number2 = input.nextInt();
	    			int totalPrime = createPrimeNumber_2_1000(result_2_1000);
	    			if(number2 == 1)
	    			{
	    				int number_of_prime_per_line = 8;
	    				System.out.print( totalPrime + " prime numbers between 2 and 1000 are as follows : \n");	 
	    				for ( int i = 1 ; i <= totalPrime ; i++)
	    				{
	    					if (i % number_of_prime_per_line == 0) 
	    					{
	    						System.out.println(result_2_1000[i - 1]);
	    					}
	    				 	else
	    				 		System.out.print(result_2_1000[i - 1] + " ");
	    				}
	    				System.out.println("");
	    			}
	    			else if( 2<= number2 && number2 <= 1000)
	    			{
	    				int isprimeE2 = java.util.Arrays.binarySearch(result_2_1000, number2);
	    				if(isprimeE2 >= 0 )
	    				{
	    					System.out.println(number2 + " is a prime integer!");
	    				}
	    				else
	    				{
	    					System.out.println(number2 + " is not a prime integer!");
	    				}
	    			}
	    			else 
	    			{
	    				System.out.println("Wrong integer!");
	    			}
	    			break;
	    		case 3:
	    			int numberPrime_10000 = primeNumber_lessThan_10000();
	    			System.out.println("The number of prime numbers less than 10000 is : " + numberPrime_10000);
	    			break;
	    	}
	    	
	    	
	    	System.out.print("Repeat program (enter 1 for yes or 0 for n)?: ");
	        repeatInt = input.nextInt();
	    } // end while(repeat loop)

	}
	public static void findTheFactorsOfAnInteger(int num)//Find the factors of an integer
	{
		int temp = num;
		String resultFactors = "";
		for(int i = 2; i <= (num/2) ; i++)
		{
			while(temp % i == 0)
			{
				resultFactors = resultFactors + i + ' ';
				temp = temp / i;
			}
		}

		System.out.println("All smallest factors of the integer " + num + " are as follows(in increasing order): " + resultFactors);
	}
	
	public static void displayPrimeNumber()//Display prime numbers between 2 and 1,000
	{
		int number_of_initial_prime = 50; // Number of primes to display
		final int number_of_prime_per_line = 8; // Display 8 per line
		int count = 0; // Count the number of prime numbers
		int number = 2; // A number to be tested for primeness
		
		System.out.println("The first 50 prime numbers are :");
		
		while (count < number_of_initial_prime) 
		{
			boolean isPrime = true; 
			for(int divisor = 2; divisor <= number/2 ; divisor++)
			{
				if (number % divisor == 0)
				{
					isPrime = false; 
					break; 
				}
			}
		
			if (isPrime) 
			{
				count++; // Increase the count
				if (count % number_of_prime_per_line == 0) 
				{
					System.out.println(number);
				}
			 	else
			 		System.out.print(number + " ");
			}				
			number++;
		}
		System.out.println("");
	}
	
	public static int createPrimeNumber_2_1000(int[] array)//Display prime numbers between 2 and 1,000
	{
		int number_start = 2 , number_end = 1000; 		
		int mark = number_start;
		int count_array = 0;
		int count_prime = 0;
		
		
		while (mark <= number_end && mark >= number_start) 
		{
			boolean isprime = true; 
			isprime = isPrime(mark);
		
			if (isprime) 
			{
				array[count_array] = mark;
				count_array++;
				count_prime++; // Increase the count
			}	
			mark++;
		}		
		return count_prime;		
	}
	
	public static boolean isPrime(int num)
	{
		boolean isprime = true;
		
		for(int divisor = 2; divisor <= num/2 ; divisor++)
		{
			if (num % divisor == 0)
			{
				isprime = false; 
				break; 
			}
		}	
		return isprime;
	}
	
	public static int primeNumber_lessThan_10000()
	{
		int number_start = 2 , number_end = 10000;
		int mark = number_start;
		int count_prime = 0;
		
		while (mark <= number_end && mark >= number_start) 
		{
			boolean isprime = true; 
			isprime = isPrime(mark);
		
			if (isprime) 
			{
				count_prime++; 
			}	
			mark++;
		}		
		return count_prime;		
		
	}
}
