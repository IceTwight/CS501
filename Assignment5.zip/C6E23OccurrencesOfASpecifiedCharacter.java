

import java.util.*;

public class C6E23OccurrencesOfASpecifiedCharacter {
	public static void main(String args[])
	{
		Scanner input = new Scanner(System.in);
		String intro = 
	    		"This program is a method that finds the number of occurrences of a specified character in a string.\n" + 
	    		" The String allows only letters and/or numbers, or also allows printable punctuation marks.";    
	    System.out.println(intro); 
	    int repeatInt = 1;//0 to quit
	    int choose_input = -1;
	    while (repeatInt != 0)
	    {
	    	System.out.print("Please choose which founction you want to use:\n" + "1:enter your string followed by a character and calculate the number of occurrences of the character in the string��  \n" + "0:if your things are done ,choose this to quit\n");
	    	choose_input = input.nextInt();
	    	if (choose_input == 0)
	    	{
	    		repeatInt = 0;
	    	}
	    	else if (choose_input == 1)
	    	{
	    		System.out.print("Please enter your string followed by a character. The string and the character should be seperated by space.(like:aaaa a) \n");
//	    		String inputString = input.next();
//	    		String temp[] = inputString.split(" ");
	    		String temp1 = input.next();
	    		String temp2 = input.next();
	    		
	    		//System.out.println(temp1);
	    		//System.out.println(temp2);
	    		try {	    			
	    			boolean validS = isValidString(temp1);
	    			//System.out.println(validS);
	    			if(validS)
	    			{
	    				char searchChar = temp2.charAt(0);
	    				int countC = count(temp1, searchChar);
	    				System.out.println(temp1 + " has " + countC +" \"" +searchChar + "\"");
	    			}
	    		}
	    		catch (IllegalArgumentException ex)
	    		{
	    			System.out.println(ex);
	    		}
	    		
	    	}
	    	else {
	    		System.out.println("Invalid input! \n");
	    	}
	    }
	}
	
	public static int count(String inputString , char searchChar )
	{
		String searchS = searchChar + "";
		int countChar = 0;
	    int index = 0;
	    while ((index = inputString.indexOf(searchChar, index)) != -1) {
	        index = index + searchS.length();
	        countChar++;
	    }
		//String partString[] = inputString.split(searchS);
		//System.out.println(partString[0]);
		//countChar = partString.length - 1;
		//System.out.println(countChar);
		return countChar;
	}
	
	public static boolean isValidString(String a)
	{
		boolean validSymbol = true;
		validSymbol = a.matches("^[A-Za-z0-9.',;=?:$\\��\\(\\)\\-\\x22]+$");
		//System.out.println(validSymbol);
		if ( validSymbol == true )
		{
			
			//System.out.println(validS);
		}
		else
		{
			throw new IllegalArgumentException("String allow only letters and/or numbers, or also allow printable punctuation marks!");
		}
		
		return validSymbol;
	}

}
