
import java.util.*;

public class MyRectangle2D extends GeometricObject{
//	double x;
//	double y; //center
//	double height;
//	double width;
	public MyRectangle2D()
	{
		setX(0);
		setY(0);
		setWidth(1);
		setHeight(1);
	}
	public MyRectangle2D(double xx , double yy , double wid , double hei) {
		setX(xx);
		setY(yy);
		setWidth(wid);
		setHeight(hei);
	}
	public void setX(double newX)
	{
		x = newX;
	}
	public double getX()
	{
		return x;
	}
	
	public void setY(double newY)
	{
		y = newY;
	}
	public double getY()
	{
		return y;
	}
	
	public void setHeight(double newH)
	{
		if(newH > 0)
			height = newH;
			else
				throw new IllegalArgumentException("height cannot be negative");
	}
	public double getHeight()
	{
		return height;
	}
	
	public void setWidth(double newW)
	{
		if(newW > 0)
			width = newW;	
			else
				throw new IllegalArgumentException("width cannot be negative");

	}
	public double getWidth()
	{
		return width;
	}
	
	public double getArea()
	{
		return width * height;
	}
	
	public double getPerimeter()
	{
		return 2 * (width + height);
	}
	
	public boolean contains ( double xC, double yC)
	{
		boolean judgeCP = false;
		if( ((x - width / 2) < xC || Math.abs((x - width / 2) - xC) < 0.000001) && (xC < (x + width / 2)|| Math.abs((x + width / 2) - xC) < 0.000001)
				&& ((y - height / 2) < yC || Math.abs((y - height / 2) - yC) < 0.000001) && (yC < (y + height / 2) || Math.abs((y + height / 2) - yC) < 0.000001) ) 
		{
			
			judgeCP = true;
		}
		return judgeCP;
	}
	
	public boolean same(MyRectangle2D r)
	{
		boolean judgeSM = false;
		if(this.x==r.getX() && this.y==r.getY() && this.height==r.height && this.width==r.width)
			judgeSM = true;
		
		return judgeSM;
	}
	
	public int abut(MyRectangle2D r)
	{
		int judgeAM = 0;
		double RH = r.getHeight() , RW = r.getWidth() , RX = r.getX(), RY = r.getY();
//		if(Math.abs((this.x - this.width/2) - (RX - RW/2)) < 0.000001)
//		{
//			if ((Math.min((this.y + this.height/2),(RY + RH/2))+0.000001) > Math.max((this.y - this.height/2),(RY - RH/2))) 
//			{
//				
//			}
//		}double RH = r.getHeight() , RW = r.getWidth() , RX = r.getX(), RY = r.getY();
		if ( Math.abs(Math.abs( this.x - RX ) - Math.abs( (this.width + RW)/2)) < 0.000001 || Math.abs(Math.abs(this.y - RY)-Math.abs(this.height + RH)/2) < 0.000001 
				|| Math.abs(Math.abs( this.x - RX ) - Math.abs( (this.width - RW)/2)) < 0.000001 ||  Math.abs(Math.abs(this.y - RY)-Math.abs(this.height - RH)/2) < 0.000001 )
		{
			return 1;
		}
		
		return 0;
		
//		if(Math.abs((this.x - this.width/2) - (RX - RW/2)) < 0.000001)
//		{
//			if (Math.min((this.y + this.height/2),(RY + RH/2)) > Math.max((this.y - this.height/2),(RY - RH/2))) 
//			{				
//				if (Math.abs((RY + RH/2) - (this.y + this.height/2)) < 0.000001)
//				{
//					System.out.println(" 2 Rectangles have left side and up side abut !");
//					judgeAM = true;
//					return judgeAM;
//				}
//				else if (Math.abs((RY - RH/2) - (this.y - this.height/2)) < 0.000001)
//				{
//					System.out.println(" 2 Rectangles have left side and down side abut !");
//					judgeAM = true;
//					return judgeAM;
//				}
//				else
//				{
//					System.out.println(" 2 Rectangles have left side abut !");
//					judgeAM = true;
//					return judgeAM;
//				}
//			}
//			if(Math.abs((this.x + this.width/2) - (RX + RW/2)) < 0.000001)
//			{
//				if (Math.min((this.y + this.height/2),(RY + RH/2)) > Math.max((this.y - this.height/2),(RY - RH/2)))
//				{				
//					if (Math.abs((RY + RH/2) - (this.y + this.height/2)) < 0.000001)
//					{
//						System.out.println(" 2 Rectangles have right side and up side abut !");
//						judgeAM = true;
//						return judgeAM;
//					}
//					else if (Math.abs((RY - RH/2) - (this.y - this.height/2)) < 0.000001)
//					{
//						System.out.println(" 2 Rectangles have right side and down side abut !");
//						judgeAM = true;
//						return judgeAM;
//					}
//					else
//					{
//						System.out.println(" 2 Rectangles have right side abut !");
//						judgeAM = true;
//						return judgeAM;
//					}
//				}
//				if(Math.abs((this.y - this.height/2) - (RY - RH/2)) < 0.000001)
//				{
//					if (Math.min((this.x + this.width/2),(RX + RW/2)) > Math.max((this.x - this.width/2),(RX - RW/2)))
//					{				
//						if (Math.abs((RX + RW/2) - (this.x + this.width/2)) < 0.000001)
//						{
//							System.out.println(" 2 Rectangles have right side and down side abut !");
//							judgeAM = true;
//							return judgeAM;
//						}
//						else if (Math.abs((RY - RH/2) - (this.y - this.height/2)) < 0.000001)
//						{
//							System.out.println(" 2 Rectangles have left side and down side abut !");
//							judgeAM = true;
//							return judgeAM;
//						}
//						else
//						{
//							System.out.println(" 2 Rectangles have down side abut !");
//							judgeAM = true;
//							return judgeAM;
//						}
//					}
//					if(Math.abs((this.y + this.height/2) - (RY + RH/2)) < 0.000001)
//					{
//						if (Math.min((this.x + this.width/2),(RX + RW/2)) > Math.max((this.x - this.width/2),(RX - RW/2)))
//						{				
//							if (Math.abs((RX + RW/2) - (this.x + this.width/2)) < 0.000001)
//							{
//								System.out.println(" 2 Rectangles have right side and up side abut !");
//								judgeAM = true;
//								return judgeAM;
//							}
//							else if (Math.abs((RY - RH/2) - (this.y - this.height/2)) < 0.000001)
//							{
//								System.out.println(" 2 Rectangles have left side and up side abut !");
//								judgeAM = true;
//								return judgeAM;
//							}
//							else
//							{
//								System.out.println(" 2 Rectangles have up side abut !");
//								judgeAM = true;
//								return judgeAM;
//							}
//						}
//				
//			//if (RY + RH/2) < (this.y + this.height/2)
//			//Math.max(RY+RH/2, this.y+this.height/2) - Math.min(RY-RH/2, this.y-this.height/2)
//		}
		//return judgeAM;
	}
	
	public boolean contains (MyRectangle2D r)
	{
		boolean judgeCM = false;
//		double H = getHeight() , W = getWidth() , X = getX(), Y = getY();
//		double RH = r.getHeight() , RW = r.getWidth() , RX = r.getX(), RY = r.getY();
//		boolean pointIn = this.contains(r.x, r.y);
//		if (pointIn)
//		{
//			if ( ( X + 0.5 * W ) > (RX + 0.5 * RW) && ( X - 0.5 * W ) < (RX - 0.5 * RW) 
//					&& ( Y + 0.5 * RH ) > (RY + 0.5 * RH) && ( Y - 0.5 * H ) < (RY - 0.5 * RH))
//				judgeCM = true;
//		}
		double rx1 , rx2 , rx3 , rx4 , ry1 , ry2 , ry3 , ry4;
		// 1  4
		// 2  3
		double RH = r.getHeight() , RW = r.getWidth() , RX = r.getX(), RY = r.getY();
		rx1 = RX - 0.5 * RW; rx2 = RX - 0.5 * RW;
		rx3 = RX + 0.5 * RW; rx4 = RX + 0.5 * RW;
		ry1 = RY + 0.5 * RH; ry2 = RY - 0.5 * RH;
		ry3 = RY - 0.5 * RH; ry4 = RY + 0.5 * RH;
		// 4 POINTS in rec
		//System.out.println(this.contains(rx1, ry1) +" "+ this.contains(rx2, ry2) + this.contains(rx3, ry3) + this.contains(rx4, ry4));
		judgeCM = this.contains(rx1, ry1) && this.contains(rx2, ry2) && this.contains(rx3, ry3) && this.contains(rx4, ry4);
		return judgeCM;
	}
	
	public boolean overlaps (MyRectangle2D r)
	{
		//boolean judgeOM = false;
		//double rx1 , rx3 , ry1 , ry3 ;
		// 1  4
		// 2  3
		double RH = r.getHeight() , RW = r.getWidth() , RX = r.getX(), RY = r.getY();
//		rx1 = RX - 0.5 * RW;  
//		rx3 = RX + 0.5 * RW; 
//		ry1 = RY + 0.5 * RH; 
//		ry3 = RY - 0.5 * RH; 
		//System.out.print(RH +" " +RW +RX+RY);
//		double BRX1 , BRX3 , BRY1 , BRY3 ;
//		BRX1 = this.x - 0.5 * this.width;  
//		BRX3 = this.x + 0.5 * this.width; 
//		BRY1 = this.y + 0.5 * this.height; 
//		BRY3 = this.y - 0.5 * this.height; 
		//System.out.print(Math.abs( this.x - RX ) +"****" +  (this.width + RW)/2 +"****"+ Math.abs(this.y - RY) +"****"+ (this.height + RH)/2);
		if(Math.abs( this.x - RX ) < ( (this.width + RW)/2 + 0.000001 ) && Math.abs(this.y - RY)<((this.height + RH)/2) + 0.000001 )
			return true;
			return false;
		// make sure 4 points one is in other 3 are not 
//		if(this.contains(rx1, ry1))
//		{
//			if ( !(this.contains(rx2, ry2) && this.contains(rx3, ry3) && this.contains(rx4, ry4)) )
//			{
//				judgeOM = true;
//			}
//		}
//		else if(this.contains(rx2, ry2))
//		{
//			if ( !(this.contains(rx1, ry1) && this.contains(rx3, ry3) && this.contains(rx4, ry4)) )
//			{
//				judgeOM = true;
//			}
//		}
//		else if(this.contains(rx3, ry3))
//		{
//			if ( !(this.contains(rx1, ry1) && this.contains(rx2, ry2) && this.contains(rx4, ry4)) )
//			{
//				judgeOM = true;
//			}
//		}else if(this.contains(rx4, ry4))
//		{
//			if ( !(this.contains(rx1, ry1) && this.contains(rx3, ry3) && this.contains(rx3, ry3)) )
//			{
//				judgeOM = true;
//			}
//		}
		
	}
	public void display()
	{
		String base = "This rectangle's properties are as follows: " + '\n' +"Center = (" +this.getX()+"," + this.getY() +")\n" + "height = " + this.getHeight() + '\n' +"width = " +this.getWidth();
		
		System.out.println(base + '\n' +"area = " +this.getArea()+'\n' + "perimeter = " + this.getPerimeter() +'\n'   );
	}
	
}
