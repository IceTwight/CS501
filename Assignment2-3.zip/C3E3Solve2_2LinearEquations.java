import java.util.Scanner;

public class C3E3Solve2_2LinearEquations
{
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		System.out.println("A linear equation can be solved using Cramer��s rule.And the formation of 2*2 linear equations are as follows : \n" + " a * x + b * y = e \n" + " c * x + d * y = f \n" + "This is a program show how to deal with it. Users who use this program should input 6 numbers separated by spaces.The first four numbers correspond four terms' coefficient (which correspond to a, b, c, d) and the last two numbers are results in 2*2 linear equations(which correspond to e, f).");
		System.out.print("Enter a,b,c,d,e,f:");
		double a = input.nextDouble();
		double b = input.nextDouble();
		double c = input.nextDouble();
		double d = input.nextDouble();
		double e = input.nextDouble();
		double f = input.nextDouble();
		double x = 0.0 , y = 0.0;		

		if ( ( a * d - b * c ) != 0 )
		{
			x = ( e * d - b * f ) / ( a * d - b * c );
			y = ( a * f - e * c ) / ( a * d - b * c );
			System.out.println(" x is " + x + " and y is " + y);
		}
		else 
		{
			System.out.println("The equation has no solution" );
		}
	}
}