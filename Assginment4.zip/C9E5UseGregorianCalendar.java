

import java.util.*;

public class C9E5UseGregorianCalendar {
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		int repeatInt = 1;
		int choose_input = -1;
	    String intro = 
	    		"The functions of this program are as follows:\n" + "Users enter 1 to display the current year, month, and day \n" + "Users enter 2 to set the value to 1234567898765L and display the year, month, and day\n"
	    + "Users enter 0 to quit";    
	    System.out.println(intro);
	    while(repeatInt != 0) 
	    {
	    	System.out.print("Please choose which founction you want to use:\n" + "1: Display the current year, month, and day \n" + "2: Set the value to 1234567898765L and display the year, month, and day\n" + "0: quit\n");
	    	choose_input = input.nextInt();
	    	if (choose_input == 0)
	    	{
	    		repeatInt = 0;
	    	}
	    	else if (choose_input == 1)
	    	{
	    		Calendar c = new GregorianCalendar();
	    		int year = c.get(GregorianCalendar.YEAR);
	    		int month = c.get(GregorianCalendar.MONTH);
	    		int date = c.get(GregorianCalendar.DAY_OF_MONTH);
	    		System.out.print("The current time is: year-" + year + " month-" + month +" day_of_month-" + date +'\n' ); 
	    		
	    	}
	    	else if (choose_input == 2)
	    	{
	    		Calendar c2 = new GregorianCalendar();
	    		c2.setTimeInMillis(1234567898765L);
	    		int year2 = c2.get(GregorianCalendar.YEAR);
	    		int month2 = c2.get(GregorianCalendar.MONTH);
	    		int date2 = c2.get(GregorianCalendar.DAY_OF_MONTH);
	    		System.out.print("The current time is: year-" + year2 + " month-" + month2 +" day_of_month-" + date2 +'\n'); 
	    	}
	    	else
	    	{
	    		System.out.print("You entered wrong number!");
	    	}
	    }
	}
}
