
import java.util.*;

public class C9E11E12TestLinearEquationAndFindIntersectingPoint {
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		int repeatInt = 1;
		int choose_input = -1;
	    String intro = 
	    		"The functions of this program are as follows:\n" + "Users enter 1 to test LinearEquation. Users who choose this should input 6 numbers separated by spaces. "
	    				+ "The first four numbers correspond four terms' coefficient (which correspond to a, b, c, d) and the last two numbers are results in 2*2 linear equations(which correspond to e, f). \n"
	    				+ "And the formation of 2*2  are as follows : \n" + " a * x + b * y = e \n" + " c * x + d * y = f \n" + "Users enter 2 to find the intersecting point by solving a linear equation\n"
	    				+ "Users enter 0 to quit";    
	    System.out.println(intro);
	    while(repeatInt != 0) 
	    {
	    	System.out.print("Please choose which founction you want to use:\n" + "1: Test LinearEquation \n" + "2: Find the intersecting point by solving a linear equation\n" + "0: quit\n");
	    	choose_input = input.nextInt();
	    	if (choose_input == 0)
	    	{
	    		repeatInt = 0;
	    	}
	    	else if (choose_input == 1)
	    	{
	    		System.out.print("Enter a,b,c,d,e,f: which are separated by spaces");
	    		double A = input.nextDouble();
	    		double B = input.nextDouble();
	    		double C = input.nextDouble();
	    		double D = input.nextDouble();
	    		double E = input.nextDouble();
	    		double F = input.nextDouble();
	    		C9E11E12LinearEquation L1 = new C9E11E12LinearEquation(A,B,C,D,E,F);
	    		boolean isSolve = L1.isSolvable();
	    		if(isSolve == false)
	    		{
	    		}
	    		else 
	    		{
	    			double x = 0.0 , y = 0.0;	
	    			x = L1.getX();
	    			y = L1.getY();
	    			System.out.println("The linear equations:\n" + L1.getterA()+ " * x + " + L1.getterB() + " * y = " +L1.getterE() +"\n" + L1.getterC() +" * x + " + L1.getterD() + " * y = " + L1.getterF()); 
	    			System.out.println("The result are as follows: x is " + x + " and y is " + y);
	    		}
	    	}
	    	else if (choose_input == 2)
	    	{
	    		System.out.print("Enter 2 points' coordinates of the 1st line:x1 y1 x2 y2 (4 numbers are separated by space)");
	    		double x1 = input.nextDouble();
	    		double y1 = input.nextDouble();
	    		double x2 = input.nextDouble();
	    		double y2 = input.nextDouble();
	    		System.out.print("Enter 2 points' coordinate of the 2nd line:x3 y3 x4 y4 (4 numbers are separated by space)");
	    		double x3 = input.nextDouble();
	    		double y3 = input.nextDouble();
	    		double x4 = input.nextDouble();
	    		double y4 = input.nextDouble();
	    		double A2 = y1 - y2;
	    		double B2 = - ( x1 - x2 );
	    		double C2 = y3 - y4;
	    		double D2 = - ( x3 - x4 );
	    		double E2 = (y1 - y2) * x1 - (x1 - x2) * y1;
	    		double F2 = (y3 - y4) * x3 - (x3 - x4) * y3;
	    		C9E11E12LinearEquation L2 = new C9E11E12LinearEquation(A2,B2,C2,D2,E2,F2);
	    		boolean isSolve = L2.isSolvable();
	    		if(isSolve == false)
	    		{
	    			System.out.print("The 2 lines do not have an intersecting point !\n");
	    		}
	    		else 
	    		{
	    			double X_intersect = 0.0 , Y_intersect = 0.0;	
	    			X_intersect = L2.getX();
	    			Y_intersect = L2.getY();
	    			System.out.print("the intersecting point's coordinate is( " +  X_intersect + " , " + Y_intersect + " )\n");
	    		}
	    	}
	    	else
	    	{
	    		System.out.print("You entered wrong number!");
	    	}
	    	
	    }
	}
}
