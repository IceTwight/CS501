

import java.util.*;

public class C9E1TestRectangle {
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		String intro = 
	    		"The functions of this program are as follows:\n" + "Users can enter 1 to get the result of test followed by textbook which is  creates two Rectangle objects��one with width 4 and height 40 " + 
	    				"and the other with width 3.5 and height 35.9. Display the width, height, area, and perimeter of each rectangle in this order\n"
	    				+ "Users can enter 2 to test the program by their own. Users can enter width and height separately according the prompt. After that users can obtain the width, height, area, and perimeter of the rectangle\n" + "Users can enter 0 to quit.";    
	    System.out.println(intro);//1 default test 2 self-test
	    int repeatInt = 1;
	    int choose_input = -1;
	    
	    while (repeatInt != 0)
	    {
	    	System.out.print("Please choose which founction you want to use:\n" + "1: get the result of test followed by textbook\n" + "2: get your own rectangle\n" + "0: quit\n");
	    	choose_input = input.nextInt();
	    	if (choose_input == 0)
	    	{
	    		repeatInt = 0;
	    	}
	    	else if (choose_input == 1)
	    	{
	    		try {
	    			C9E1Rectangle R1 = new C9E1Rectangle(4,40);
	    			C9E1Rectangle R2 = new C9E1Rectangle(3.5,35.9);
	    			R1.printRectangle();
	    			R2.printRectangle();	    	
	    			//	    	System.out.println("The first rectangle R1's information is as follows:");
	    			//		    System.out.println("width: " + R1.getWidth() + " height: " + R1.getHeight() + " area: " + R1.getArea() +" perimeter: " + R1.getPerimeter() );
	    			//	    	System.out.println("The second rectangle R2's information is as follows:");
	    			//		    System.out.println("width: " + R2.getWidth() + " height: " + R2.getHeight() + " area: " + R2.getArea() +" perimeter: " + R2.getPerimeter() );
	    		}
	    		catch (IllegalArgumentException ex)
	    		{
	    			System.out.println(ex);
	    		}
	    		
	    	}
	    	else if (choose_input == 2)
	    	{
	    		System.out.print("Please enter the width of the rectangle:");
	    		double width_input = input.nextDouble();
	    		System.out.print("Please enter the height of the rectangle:");
	    		double height_input = input.nextDouble();
	    		try {
	    			C9E1Rectangle R3 = new C9E1Rectangle(width_input,height_input);	    			
	    			R3.printRectangle();
	    		}
	    		catch (IllegalArgumentException ex)
	    		{
	    			System.out.println(ex);
	    		}
	    	}
	    	else 
	    	{
	    		System.out.print("You entered wrong number!");
	    	}
	    }
	    
	    
	    
	}
	

}
