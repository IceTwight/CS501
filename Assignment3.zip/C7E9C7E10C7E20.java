
import java.util.Scanner;
import java.util.Arrays;

public class C7E9C7E10C7E20 {
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		int repeatInt = 1;
	    String intro = 
	    		"The functions of this program are as follows:\n" + "User should enter ten numbers which are seperated by space(like:1.9 2.5 3.7 2 1.5 6 3 4 5 2)."
	    				+ " Then the minimum and its index will be reported. Then the list will be sorted by using Revised Selection Sort.";    
	    System.out.println(intro);
	    while(repeatInt != 0) 
	    {
	    	System.out.print("Please enter ten numbers which are seperated by space(like:1.9 2.5 3.7 2 1.5 6 3 4 5 2):");
	    	String user_input = input.nextLine();
	    	int space_num = calculate(user_input, " ");
	    	//System.out.println(space_num);
			if( space_num != 9)
			{
				System.out.println("The input is invalid !");
			}
			else 
			{
				double[] arrayInput = new double[10];
		    	int start_temp = 0;
		    	int end_temp = user_input.indexOf(' ');
		    	int judge_valid = 1;//judge is number		    	
		    	for( int judge = 0; judge < 10; judge++)
		    	{	
		    		String temp_judge = user_input.substring(start_temp, end_temp);
		    		for(int i = start_temp - start_temp; i < end_temp - start_temp; i++)
		    		{
		    			char c = temp_judge.charAt(i);
		    			if(!((c >= '0' && c <= '9')||c=='.'))
		    			{
		    				judge_valid = 0;
		    			}
		    		}
		    		start_temp = end_temp+1;
	    			end_temp = user_input.indexOf(' ' , start_temp);
	    			if( end_temp < 0 )
	    			{
	    				end_temp = user_input.length();
	    				if(end_temp == start_temp)
	    				{
	    					judge_valid = 0;
	    				}
	    			}
		    	}
		    	if (judge_valid == 0)
		    	{
		    		System.out.println("The input is invalid !");
		    	}
		    	else
		    	{
		    		start_temp = 0;
			    	end_temp = user_input.indexOf(' ');
		    		for( int i = 0; i < 10; i++)
		    		{			    			
		    			int k = user_input.length();
		    			arrayInput[i] = Double.parseDouble(user_input.substring(start_temp, end_temp));
		    			start_temp = end_temp+1;
		    			end_temp = user_input.indexOf(' ' , start_temp);
		    			if( end_temp < 0 )
		    			{
		    				end_temp = user_input.length();
		    			}
		    		}
//		    	for( int t = 0; t < 10; t++)
//		    	{
//		    		System.out.print(" " + arrayInput[t]);
//		    	}
//		    	
		    		double min_num = min(arrayInput);
		    		int min_num_index =indexOfSmallestElement(arrayInput);
		    		System.out.println("The minimum and its index of the list is : the " + (min_num_index + 1) + "th number whose value is : " + min_num);
		    		reviseSelectionSort(arrayInput);
		    		System.out.println("List which is sorted by using Revised Selection Sort are as follows:" );
		    		for( int t = 0; t < 10; t++)
		    		{
		    			System.out.print(" " + arrayInput[t]);
		    		}		    		
		    	}
			}
	    	
	    	System.out.println("");
	    	System.out.print("Repeat program (enter 1 for yes or 0 for n)?: ");
	        repeatInt = Integer.parseInt(input.nextLine());
	    } // end while(repeat loop)

	}
    public static int calculate(String str, String substr) {
        String temp = str;
        int count = 0;
        int index = temp.indexOf(substr);
        while (index != -1) {
            temp = temp.substring(index + 1);
            index = temp.indexOf(substr);
            count++;
        }
        return count;
    }
//	public static int stringNumbers(String str)
//	{
//		if (str.indexOf(' ')==-1)
//		{
//			return 0;
//		}
//		else if(str.indexOf(' ') != -1)
//		{
//			counter++;
//			stringNumbers(str.substring(str.indexOf(' ')+1));
//			return counter;
//		}
//		return 0;
//	}
	public static double min(double[] array)
	{
		double result = Double.MAX_VALUE;
		for (int i = 0 ; i < array.length ; i++)
		{
			if( result > array[i])
			{
				result = array[i];
			}
		}	
		return result;
	}
	
	public static int indexOfSmallestElement(double[] array)
	{
		double min = Double.MAX_VALUE;
		int count = 0;
		for (int i = 0 ; i < array.length ; i++)
		{
			if( min > array[i])
			{
				min = array[i];
				count = i;
			}
		}	
		return count;
	}
	
	//Revise selection sort
	public static void reviseSelectionSort(double[] list)
	{
		for (int i = list.length - 1; i > 0 ; i--)
		{
			double currentMax = list[i];
			int currentMaxIndex = i;
			
			for (int j = i - 1; j >= 0 ; j--)
			{
				if (currentMax < list[j])
				{
					currentMax = list[j];
					currentMaxIndex = j;
				}
			}
			if (currentMaxIndex != i)
			{
				list[currentMaxIndex] = list[i];
				list[i] = currentMax;
			}
		}
	}
}
