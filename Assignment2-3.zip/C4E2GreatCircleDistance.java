import java.util.Scanner;

public class C4E2GreatCircleDistance
{
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		final double radius = 6371.01;
		System.out.println("The program is used to calculate the great circle distance which is the distance between two points on the surface of a sphere. Users should input like : x1, y1 and x2, y2 which are the geographical latitude and longitude of two points. ");
		String X1  = " " ,Y1 = " "  , X2 = " "  , Y2 = " " ; 
		int i1 = 0 , i11 = 0 , i2 = 0 , i22 = 0;
		System.out.print("Enter point 1 (latitude and longitude) in degrees:");
		String point1 = input.nextLine();
		if ( point1.indexOf(',') >= 0 )
		{
			i1 = point1.indexOf(',');
			X1 = point1.substring(0 , i1);
			Y1 = point1.substring(i1+1);
		}
		else 
		{
			i11 = point1.indexOf(' ');
			X1 = point1.substring(0 , i11);
			Y1 = point1.substring(i11+1);
		}
		double x1 = Double.parseDouble(X1);
		double y1 = Double.parseDouble(Y1);
		x1 = Math.toRadians(x1);
		y1 = Math.toRadians(y1);
		//System.out.println( x1 + ";" + y1 + ";" + i1 + ";" + i11 + X1 + ";" + Y1 );

		System.out.print("Enter point 2 (latitude and longitude) in degrees:");
		String point2 = input.nextLine();
		if( point2.indexOf(',') >= 0 )
		{
			i2 = point2.indexOf(',');
			X2 = point2.substring(0 , i2);
			Y2 = point2.substring(i2+1);
		//System.out.println( i2 + ";" + i22 + X2 + ";" + Y2);
		}
		else
		{
			i22 = point2.indexOf(' ');
			X2 = point2.substring(0 , i22);
			Y2 = point2.substring(i22+1);
		}
		double x2 = Double.parseDouble(X2);
		double y2 = Double.parseDouble(Y2);
		x2 = Math.toRadians(x2);
		y2 = Math.toRadians(y2);
		//System.out.println( x2 + ";" + y2 + ";" + i2 + ";" + i22 + X2 + ";" + Y2);

		double d = radius * Math.acos( Math.sin(x1) * Math.sin(x2) + Math.cos(x1) * Math.cos(x2) * Math.cos(y1 - y2) );
		System.out.print("The distace between the two points is " + d + " km ");
		
	}
}