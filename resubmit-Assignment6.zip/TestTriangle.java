
import java.util.*;

public class TestTriangle extends Triangle{
	public static void main(String args[]) throws GeometricObject.IllegalTriangleException
	{
		Scanner input = new Scanner(System.in);
		String intro = 
	    		"This program is used to create a Triangle through Triangle object with sides \r\n" + 
	    		"and set the color and filled properties using the input. The program also display\r\n" + 
	    		"the area, perimeter, color, and true or false to indicate whether it is filled or not after the filled property is set.";    
	    System.out.println(intro);
	    int repeatInt = 1;//0 to quit
	    
	    while (repeatInt != 0)
	    {
	    	System.out.print("You can enter 0 for quit Or 1 for creating a new triangle and display:");
	    	repeatInt = input.nextInt();
	    	if(repeatInt == 1)
	    	{
	    		System.out.println("You can enter 3 double values of the sides seperated by space :(like: 11.1 22.2 15)");
	    		double sideIn1 = Double.parseDouble(input.next());
	    		double sideIn2 = Double.parseDouble(input.next());
	    		double sideIn3 = Double.parseDouble(input.next());
	    		//System.out.print(sideIn1+sideIn2+sideIn3);
	    		try
	    		{
	    			Triangle t1 = new Triangle(sideIn1, sideIn2, sideIn3);
		    		t1.setColor("white");
		    		t1.setFilled(false);
		    		System.out.println("Please enter the color of the triangle : (enter a string like: red) default:white");
		    		String colorIn = input.next();
		    		t1.setColor(colorIn);
		    		System.out.println("Please enter a number to fill the triangle or not (0 : not fill 1: fill) default:not filled");
		    		int fill = input.nextInt();
		    		if (fill == 1)
		    		{
		    			t1.setFilled(true);
		    		}
		    		System.out.println("The triangle's properties are as follows:");
		    		t1.display();
		    		
	    		}
	    		catch(IllegalTriangleException ex)
	    		{
	    			System.out.println(ex.getMessage());
	    		}
//	    		Triangle t1 = new Triangle(sideIn1, sideIn2, sideIn3);
//	    		t1.setColor("white");
//	    		t1.setFilled(false);
//	    		System.out.println("Please enter the color of the triangle : (enter a string like: red) default:white");
//	    		String colorIn = input.next();
//	    		t1.setColor(colorIn);
//	    		System.out.println("Please enter a number to fill the triangle or not (0 : not fill 1: fill) default:not filled");
//	    		int fill = input.nextInt();
//	    		if (fill == 1)
//	    		{
//	    			t1.setFilled(true);
//	    		}
//	    		System.out.println("The triangle's properties are as follows:");
//	    		t1.display();
	    		
	    		//System.out.print(t1.getArea()+"***"+  t1.getPerimeter()+ ")))))))"+t1.getColor()+ t1.toString());
	    		
	    	}
	    	
	    }
	}
}
