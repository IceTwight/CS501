
import java.util.*;


public class C6E18CheckPassword {
	public static void main(String args[])
	{
		Scanner input = new Scanner(System.in);
		String intro = 
	    		"This program is used to check whether a string is a valid password. The password rules are as follows:\r\n" + 
	    		"�� A password must have at least eight characters.\n" + 
	    		"�� A password consists of only letters and digits.\n" + 
	    		"�� A password must contain at least two digits.\n" + "Users should choose 1 to enter the check password part or 0 for quit. After users choose"
	    				+ "1, they can enter their password after prompts then the result will be displayed.";    
	    System.out.println(intro);
	    int repeatInt = 1;//0 to quit
	    int choose_input = -1;
	    while (repeatInt != 0)
	    {
	    	System.out.print("Please choose which founction you want to use:\n" + "1: enter your password and check the validation of the password \n" + "0: quit\n");
	    	choose_input = input.nextInt();
	    	if (choose_input == 0)
	    	{
	    		repeatInt = 0;
	    	}
	    	else if (choose_input == 1)
	    	{
	    		System.out.print("Please enter your password: \n");
	    		String inputString = input.next();
	    		//System.out.println(inputString + "DDD");
	    		try {
	    			
	    			boolean validS = isValidString(inputString);
	    			//System.out.println(validS);
	    			if(validS)
	    			{
	    				System.out.println("Valid password! \n" );
	    			}
	    		}
	    		catch (IllegalArgumentException ex)
	    		{
	    			System.out.println(ex);
	    		}	    		
	    	}
	    	else {
	    		System.out.println("Invalid input! \n");
	    	}
	    }
	}
	
	public static boolean isValidString(String a )
	{
		boolean validSymbol = true;
		validSymbol = a.matches("^[A-Za-z0-9]+$");
		//System.out.println(validSymbol);
		if ( validSymbol == true )
		{
			validSymbol = a.matches("\\w*\\d\\w*\\d\\w*");
			if( validSymbol == true )
			{
				String temp[] = a.split("[0-9]");
				String tempsum = "";
				for ( int i = 0 ; i < temp.length ; i++)
				{
					tempsum += temp[i];
				}
				//System.out.println(tempsum);
				validSymbol = tempsum.matches("\\w{8}\\w*");
				//System.out.println(validSymbol);
				if( validSymbol == true )
				{
					//validS = validSymbol;
				}
				else
				{
					throw new IllegalArgumentException("Password must have at least 8 characters!");
				}
			}
			else
			{
				throw new IllegalArgumentException("Password must contain at least 2 digits!");
			}
		}
		else
		{
			throw new IllegalArgumentException("Password consists of only letters and digits!");
		}
		
		return validSymbol;
		
		//validSymbol = a.matches("\\d\\w*\\d");
		
//		if(setW > 0)
//			 width = setW;
//			else
//				throw new IllegalArgumentException("width cannot be negative");
		
	}
}
