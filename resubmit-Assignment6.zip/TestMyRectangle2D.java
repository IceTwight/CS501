

import java.util.*;

public class TestMyRectangle2D {
	public static void main(String args[])
	{
		Scanner input = new Scanner(System.in);
		String intro = 
	    		"This program is used to creates a MyRectangle2D object with values of height, width, center point(x,y)\n" + 
	    		"and can displays its area and perimeter,\n"
	    		+ "and displays the result of whether the specified point (x, y) is inside this rectangle \n" + 
	    		"and displays the result of whether the specified rectangle is inside this base rectangle \n" + 
	    		"and displays the result of whether the specified rectangle overlaps with this base rectangle \n" + 
	    		"\n"
	    		+"Users should follow the prompt to create the base rectangular first \n"
	    		+ "and choose 1 to get result of whether the specified point (x, y) is inside this rectangle"
	    		+ "choose 2 to get result of whether the specified rectangle is inside this base rectangle or overlaps with this base rectangle \n";    
	    System.out.println(intro);
	    int repeatInt = 1;//0 to quit
	    
	    while (repeatInt != 0)// extern loop
	    {
	    	int baseRectangleDone = 0;
	    	while (baseRectangleDone == 0)
	    	{
	    		System.out.print("Users please enter to create the Base Rectangular : \n"
	    				+ "4 double values which is coordinate x of the center point, coordinate y of the center point, the height of the rectangular, the width of the rectangular\n"
	    				+ " (like:1.0 2.0 11.11 11.11) ");
	    		//base rectangle
	    		double x= Double.parseDouble(input.next());
	    		double y= Double.parseDouble(input.next());
	    		double width= Double.parseDouble(input.next());
	    		double height= Double.parseDouble(input.next());
	    		//System.out.print(height + "&&" + width + " " + x + ' ' + y);
	    		try
	    		{
	    			//GeometricObject r1 = new GeometricObject() ;
	    			
	    			MyRectangle2D r1 = new MyRectangle2D(x, y ,width , height);
	    			r1.display();
	    			//System.out.println(r1.height +"    "+ r1.width +"  " + r1.x+r1.y+" " + r1.getHeight()+" " +r1.getArea());
	    			if (baseRectangleDone == 0)
		    		{
		    			int testDone = 0;
		    			while (testDone == 0)
		    			{
		    				//test rectangle
		    				int choose_input = -1;
		    				System.out.println("Users please enter 0 for quit and 1 for test point and 2 for test rectangle(include : inside judgement and overlap judgement)" );
		    				choose_input = input.nextInt();
		    				if( choose_input == 0 )
		    				{
		    					testDone = 1;
		    					baseRectangleDone = 1;
		    					repeatInt = 1;
		    				}
		    				else if (  choose_input == 1 )
		    				{
		    					System.out.print("Users please enter coordinate x of the test point, coordinate y of the test point: 2 value seperated by space(like:1.5 2.3)");
		    					double TestPointX = Double.parseDouble(input.next());
		    		    		double TestPointY = Double.parseDouble(input.next());
		    		    		//System.out.print(TestPointX + "  " + TestPointY);
		    					boolean containP = r1.contains(TestPointX, TestPointY);
		    					if (containP)
		    					{
		    						System.out.println("the specified point ("+TestPointX+", "+TestPointY+") is inside this rectangle");
		    					}
		    					else
		    					{
		    						System.out.println("the specified point ("+TestPointX+", "+TestPointY+") is outside this rectangle");
		    					}
		    				}
		    				else if (  choose_input == 2 )
		    				{
		    					System.out.print("Users please enter to create the Test Rectangular : \n"
		    		    				+ "4 double values which is coordinate x of the center point, coordinate y of the center point, the height of the rectangular, the width of the rectangular\n"
		    		    				+ "(like:1.0 2.0 11.11 11.11)" );
		    		    		//test rectangle
		    		    		double Tx = Double.parseDouble(input.next());
		    		    		double Ty = Double.parseDouble(input.next());
		    		    		double Twidth = Double.parseDouble(input.next());
		    		    		double Theight = Double.parseDouble(input.next());
		    		    		try
		    		    		{
		    		    			MyRectangle2D rT = new MyRectangle2D( Tx , Ty , Twidth , Theight);
		    		    			rT.display();
		    		    			boolean TestRecC = r1.contains(rT);
		    		    			boolean TestRecO = r1.overlaps(rT);
		    		    			boolean TestRecS = r1.same(rT);
		    		    			int TC_A = r1.abut(rT);
		    		    			
		    		    			//System.out.print(TC_A + "##"+ TestRecO);
		    		    			if ( TestRecS )
		    		    			{
		    		    				System.out.println("the two rectangles are totally same!");
		    		    			}
		    		    			else if ( TestRecC )
		    		    			{
		    		    				if (TC_A == 1) 
		    		    				{
		    		    					
		    		    					System.out.println("the test rectangle abuts this base rectangle!");
		    		    					if(Math.abs(Math.abs( r1.x - rT.x ) - Math.abs( (r1.width - rT.width)/2)) < 0.000001 )
		    		    					{
		    		    						if(r1.x > rT.x)
		    		    						{
		    		    							System.out.print("the test rectangle abuts this base rectangle on the left side! \n" + "AND ");
		    		    						}
		    		    						else
		    		    						{
		    		    							System.out.print("the test rectangle abuts this base rectangle on the right side! \n" + "AND ");
		    		    						}
		    		    					}
		    		    					if	(Math.abs(Math.abs(r1.y - rT.y)-Math.abs(r1.height - rT.height)/2) < 0.000001)
		    		    					{
		    		    						if(r1.y > rT.y)
		    		    						{
		    		    							System.out.print("the test rectangle abuts this base rectangle on the down side! \n" + "AND ");
		    		    						}
		    		    						else
		    		    						{
		    		    							System.out.print("the test rectangle abuts this base rectangle on the up side! \n" + "AND ");
		    		    						}
		    		    					}
		    		    				}
		    		    				System.out.println("the test rectangle is inside this base rectangle!");
		    		    			}
		    		    			else if (TestRecO)
		    		    			{
		    		    				if (TC_A == 1) 
		    		    				{
		    		    					System.out.println("the test rectangle abuts this base rectangle!");
		    		    					if(Math.abs(Math.abs( r1.x - rT.x ) - Math.abs( (r1.width - rT.width)/2)) < 0.000001 )
		    		    					{
		    		    						if(Math.abs(r1.x - rT.x) < 0.000001)
		    		    						{
		    		    							System.out.print("the test rectangle abuts this base rectangle on both the left side and the right side!\n");
		    		    						}
		    		    						else if(r1.x > rT.x)
		    		    						{
		    		    							System.out.print("the test rectangle abuts this base rectangle on the left side! \n" + "AND ");
		    		    						}
		    		    						else
		    		    						{
		    		    							System.out.print("the test rectangle abuts this base rectangle on the right side! \n" + "AND ");
		    		    						}
		    		    					}
		    		    					if	(Math.abs(Math.abs(r1.y - rT.y)-Math.abs(r1.height - rT.height)/2) < 0.000001)
		    		    					{
		    		    						if(Math.abs(r1.y - rT.y) < 0.000001)
		    		    						{
		    		    							System.out.print("the test rectangle abuts this base rectangle on both the up side and the down side!\n");
		    		    						}
		    		    						else if(r1.y > rT.y)
		    		    						{
		    		    							System.out.print("the test rectangle abuts this base rectangle on the down side! \n" + "AND ");
		    		    						}
		    		    						else
		    		    						{
		    		    							System.out.print("the test rectangle abuts this base rectangle on the up side! \n" + "AND ");
		    		    						}
		    		    					}
		    		    				}
		    		    				System.out.println("the test rectangle overlaps with this base rectangle!");
		    		    			}
		    		    			else if(TC_A == 1)
		    		    			{
		    		    				System.out.println("the test rectangle abuts this base rectangle from outside!");
		    		    				if(Math.abs(Math.abs( r1.x - rT.x ) - Math.abs( (r1.width + rT.width)/2)) < 0.000001 )
	    		    					{
	    		    						if(r1.x > rT.x)
	    		    						{
	    		    							System.out.print("the test rectangle abuts this base rectangle on the left side of the base rec! \n" + "AND ");
	    		    						}
	    		    						else
	    		    						{
	    		    							System.out.print("the test rectangle abuts this base rectangle on the right side of the base rec! \n" + "AND ");
	    		    						}
	    		    					}
	    		    					if	(Math.abs(Math.abs(r1.y - rT.y)-Math.abs(r1.height + rT.height)/2) < 0.000001)
	    		    					{
	    		    						if(r1.y > rT.y)
	    		    						{
	    		    							System.out.print("the test rectangle abuts this base rectangle on the down side of the base rec! \n" + "AND ");
	    		    						}
	    		    						else
	    		    						{
	    		    							System.out.print("the test rectangle abuts this base rectangle on the up side of the base rec! \n" + "AND ");
	    		    						}
	    		    					}
		    		    			
		    		    			}
		    		    			else
		    		    			{
		    		    				System.out.println("the test rectangle is district with this base rectangle!");
		    		    			}
		    		    		}
		    		    		catch (IllegalArgumentException ex)
		    		    		{
		    		    			System.out.println(ex.getMessage());
		    		    		}
		    				}
		    				
		    			}	
		    			
		    		}
	    		}
	    		catch(IllegalArgumentException ex)
	    		{
	    			System.out.print("Please enter a new one." );
	    		}
	    	
	    		
	    		
	    		
	    	}
	    	
	    } 
	}
}
