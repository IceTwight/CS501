
import java.io.File;
import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Exercise14_01 extends Application{
	@Override
	public void start(Stage primaryStage)
	{
		GridPane pane = new GridPane();
		pane.setAlignment(Pos.CENTER);
		pane.setPadding(new Insets(2,2,2,2));
		pane.setHgap(6);
		pane.setVgap(6);
		
		String s = System.getProperty("user.dir");
		String s1 = "file:" + s + '\\';
		Image image1 = new Image(s1 + "uk.png");
		//System.out.println(new File("uk.png").toURI().toString());	
		pane.add(new ImageView(image1), 0, 0);
		Image image2 = new Image(s1 + "ca.png");
		pane.add(new ImageView(image2), 0, 1);
		Image image3 = new Image(s1 + "ch.png");
		ImageView imageV3 = new ImageView(image3);
		pane.add(imageV3, 1, 0);
		GridPane.setHalignment(imageV3, HPos.LEFT);
		Image image4 = new Image(s1 + "us.png");
		ImageView imageV4 = new ImageView(image4);
		pane.add(imageV4, 1, 1);
		GridPane.setHalignment(imageV4, HPos.LEFT);
		Scene scene = new Scene(pane);
		primaryStage.setTitle("Exercise14_01");
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	
	public static void main(String[] args) {
		Application.launch(args);
		}

	
}
